import 'package:flutter/material.dart';

class CustomCircleProgressIndicictor extends StatelessWidget {
  const CustomCircleProgressIndicictor({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: CircularProgressIndicator());
  }
}
