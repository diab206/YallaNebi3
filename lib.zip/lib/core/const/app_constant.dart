class Appconstant {
  static const String appName = 'Yalla Nebi3';
  static const String appVersion = '1.0.0';
  static const String appDescription =
      'A Flutter application for managing and sharing recipes.';
  static const String apiBaseUrl = 'https://api.yallanebi3.com';
  static const String privacyPolicyUrl =
      'https://www.yallanebi3.com/privacy-policy';
  static const String termsOfServiceUrl =
      'https://www.yallanebi3.com/terms-of-service';
}
