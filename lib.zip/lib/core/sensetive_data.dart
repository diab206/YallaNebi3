const String anonKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVpdGdhcHRqZmJobnZrYmFxeXZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI4NDU4ODAsImV4cCI6MjA2ODQyMTg4MH0.YMrLyyoWFrEE4CusSxi_XyMEQK3AvrsqOG8XIvdWkzc';
const String supabaseUrl = 'https://eitgaptjfbhnvkbaqyvt.supabase.co';


// Payment integration keys
const String paymobApiKey="ZXlKaGJHY2lPaUpJVXpVeE1pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SmpiR0Z6Y3lJNklrMWxjbU5vWVc1MElpd2ljSEp2Wm1sc1pWOXdheUk2TVRBMk56WTJNaXdpYm1GdFpTSTZJbWx1YVhScFlXd2lmUS5pZUxkeVZVTU96Mk15cnc1M2ZNdzFzV3dSeDRjd09nVHdEY2NlOGlIRGdKV1VPeHB1bUh0VDg0Uktxdlc4Vkc1RDE4STlFWnllaXBoWHNoUVlmaW5IZw==";// Required: Found under Dashboard -> Settings -> Account Info -> API Key
const String iframeId = '948334';
const String integrationCardId = '5233026';
const String integrationMobileWalletId = '5233053';
